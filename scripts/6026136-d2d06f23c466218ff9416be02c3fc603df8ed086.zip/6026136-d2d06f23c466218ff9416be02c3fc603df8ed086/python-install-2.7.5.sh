#!/usr/bin/env bash

cd /tmp

# Install dependencies
aptitude -y install build-essential python-pip libmysqlclient-dev libadns1-dev \
 python-dev libreadline-dev libgdbm-dev zlib1g-dev libsqlite3-dev \
 libssl-dev libbz2-dev libncurses5-dev libdb-dev 

# Download latest version
wget http://python.org/ftp/python/2.7.5/Python-2.7.5.tar.xz
unxz -c Python*xz | tar xpf -

# compile
cd Python*
./configure  --prefix=/opt/python2.7.5 --enable-shared
make

# install
make install
echo "/opt/python2.7.5/lib" >  /etc/ld.so.conf.d/libpython2.7.conf
ldconfig

# test
/opt/python2.7.5/bin/python -c "print('Ok')" 

# Upgrade pip virtualenv
easy_install pip
pip -v install --upgrade distribute==0.7.3
pip -v install --upgrade virtualenv==1.9.1

# Create an user
adduser user_app --home /opt/user_app
su user_app
virtualenv --no-site-packages --verbose -p /opt/python2.7.5/bin/python $HOME

# test again
su user_app
cd 
source bin/activate
python -c "import sys; print sys.version"
